---
layout: page
title: Contactez-nous
permalink: /contact/
---

<h3>Nous sommes présentemment à la recherche d'étudiants de tous les départements.</h3>

Nous recrutons en tout temps! Tu recherches de beaux défis et tu te demandes quoi faire dans tes temps libres? Tu veux gagner de l’expérience et t’amuser? Tu es la personne qu’il nous faut!

Pour plus de détails ou bien pour jaser, passe nous voir en personne au local A-1746 ou envois nous un message à l’adresse [capra@clubcapra.com](mailto:capra@clubcapra.com). Capra, c’est un club jeune et dynamique qui laisse place aux idées de tous!