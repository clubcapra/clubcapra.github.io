---
layout: post
title: Capra recrute une équipe administrative
redirect_from: "/recrutement"
category: news
---

<big>Capra recrute une équipe administrative! Diversifie tes compétences en relevant des nouveaux défis dans les domaines:</big>

**Trésorerie**

* Planification, réalisation et suivi budgétaire
* Gestion des dépenses opérationnelles
* Demandes de financement ÉTS & RACÉ

**Administration**

* Gestion de l'adhésion et des membres
* Relations avec les commanditaires et plan
* Relations avec l'ÉTS 
 
**Communications**

* Promotion du club et évènements
* Site web et médias sociaux
* Recrutement

**Logistique**

* Coordination et planification interdépartementale
* Optimisation des espaces et des processus de travail
* Opérations logistiques de compétitions


La technique t'intéresse aussi? Capra recrute dans tous les programmes pour des projets en **logiciel**, **mécanique** et **électrique**. 

Pour en savoir plus et convenir d'une rencontre, contactez-nous: <a href="&#x6d;&#97;&#x69;&#x6c;&#116;&#111;&#x3a;&#99;&#x61;&#112;&#114;&#97;&#x40;&#99;&#108;&#117;&#x62;&#x63;&#97;&#x70;&#114;&#97;&#46;&#99;&#111;&#109;">&#99;&#97;&#112;&#x72;&#97;&#64;&#99;&#x6c;&#117;&#x62;&#x63;&#x61;&#x70;&#x72;&#97;&#46;&#99;&#x6f;&#x6d;</a>.