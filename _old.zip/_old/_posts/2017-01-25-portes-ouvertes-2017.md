---
layout: post
title: Portes ouvertes 2017
category: news
---
Capra sera à la Journée portes ouvertes cette année encore! Venez voir notre véhicule autonome et découvrir nos nouveaux projets pour 2017-2018.

<img src="/img/portesouvertes2016.jpg" >