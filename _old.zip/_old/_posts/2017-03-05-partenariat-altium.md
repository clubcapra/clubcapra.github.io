---
layout: post
title: Partenariat avec Altium 
category: news
---

<img src="/include/img/logos/altium.png" class="post-right-image"> 

Capra se fie à la puissance de Altium Designer pour la conception des circuits imprimés qui contrôleront la future génération de son véhicule autonome! Grâce à cet outil, l'équipe électrique pourra s'atteler au design des pièces maitresses plus efficacement et plus rapidement. L'objectif est de produire des composantes électriques valides, robustes, sécuritaires. En fournissant les meilleurs outils à nos équipes, Capra contribue à la formation de la relève en robotique. 

Capra remercie [Altium](http://www.altium.com/) pour sa contribution au rayonnement étudiant! Par son engagement, Altium promeut l'innovation et l'avancement technologiques en conception électronique. 

Cette commandite, d'une valeur de près de 20 000$, permettra à Capra d'acquérir Altium Designer et propulser son développement électronique. 

Merci Altium! 

<img src="/img/igvc2016-j4-p1.jpg" style="max-width: 100%">
